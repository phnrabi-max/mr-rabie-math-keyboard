
package com.mohammedrabie.mathkeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*

class MainActivity : Activity() {

    private lateinit var num: EditText
    private lateinit var den: EditText
    private lateinit var rad: EditText
    private lateinit var idx: EditText
    private lateinit var base: EditText
    private lateinit var exp: EditText
    private lateinit var preview: WebView
    private lateinit var output: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            setBackgroundColor(0xFFF4F7FB.toInt())
        }

        page.addView(TextView(this).apply {
            text = "Mister Mohammed Rabie\nMath Editor"
            textSize = 24f
            setTextColor(0xFF17365D.toInt())
            setPadding(0, 0, 0, 20)
        })

        page.addView(Button(this).apply {
            text = "Enable Keyboard"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
                )
            }
        })

        page.addView(Button(this).apply {
            text = "Select Keyboard"
            setOnClickListener {
                val imm = getSystemService(
                    Context.INPUT_METHOD_SERVICE
                ) as InputMethodManager

                imm.showInputMethodPicker()
            }
        })

        num = addField(page, "Numerator")
        den = addField(page, "Denominator")
        rad = addField(page, "Radicand")
        idx = addField(page, "Root Index (2, 3, n)")
        base = addField(page, "Base")
        exp = addField(page, "Exponent")

        page.addView(Button(this).apply {
            text = "Generate & Preview Formula"
            setOnClickListener {
                renderFormula()
            }
        })

        preview = WebView(this).apply {
            settings.javaScriptEnabled = true
            webViewClient = WebViewClient()
            layoutParams = LinearLayout.LayoutParams(
                -1, 250
            )
        }

        page.addView(preview)

        page.addView(TextView(this).apply {
            text = "LaTeX Code:"
            textSize = 18f
            setTextColor(0xFF17365D.toInt())
            setPadding(0, 15, 0, 5)
        })

        output = TextView(this).apply {
            textSize = 14f
            setTextIsSelectable(true)
            setTextColor(0xFF222222.toInt())
            setPadding(10, 10, 10, 10)
        }

        page.addView(output)

        page.addView(Button(this).apply {
            text = "Copy LaTeX Code"
            setOnClickListener {
                val clipboard =
                    getSystemService(
                        Context.CLIPBOARD_SERVICE
                    ) as android.content.ClipboardManager

                clipboard.setPrimaryClip(
                    android.content.ClipData.newPlainText(
                        "LaTeX",
                        output.text
                    )
                )

                Toast.makeText(
                    this@MainActivity,
                    "LaTeX code copied",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })

        setContentView(
            ScrollView(this).apply {
                addView(page)
            }
        )

        renderFormula()
    }

    private fun addField(
        parent: LinearLayout,
        hintText: String
    ): EditText {

        val field = EditText(this).apply {
            hint = hintText
            textSize = 16f
            singleLine = true
        }

        parent.addView(field)
        return field
    }

    private fun renderFormula() {

        val n = num.text.toString().ifBlank { "a+b" }
        val d = den.text.toString().ifBlank { "x+y" }
        val r = rad.text.toString().ifBlank { "x" }
        val k = idx.text.toString().ifBlank { "2" }
        val b = base.text.toString().ifBlank { "x" }
        val e = exp.text.toString().ifBlank { "2" }

        val latex =
            """\frac{$n}{$d} \quad + \sqrt[$k]{$r} \quad + {$b}^{$e}"""

        output.text = latex

        val html = """
            <!doctype html>
            <html>
            <head>
            <meta name="viewport"
            content="width=device-width, initial-scale=1">

            <script>
            window.MathJax = {
                tex: {
                    inlineMath: [['\\(', '\\)']]
                },
                svg: {
                    fontCache: 'global'
                }
            };
            </script>

            <script defer
            src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js">
            </script>

            <style>
            body {
                font-family: sans-serif;
                background: #ffffff;
                color: #17365d;
                padding: 18px;
                font-size: 22px;
            }
            </style>

            </head>
            <body>
            <div>\($latex\)</div>
            </body>
            </html>
        """.trimIndent()

        preview.loadDataWithBaseURL(
            "https://cdn.jsdelivr.net",
            html,
            "text/html",
            "UTF-8",
            null
        )
    }
}
