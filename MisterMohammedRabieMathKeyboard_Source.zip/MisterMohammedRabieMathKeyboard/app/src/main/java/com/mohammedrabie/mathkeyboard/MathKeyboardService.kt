package com.mohammedrabie.mathkeyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MathKeyboardService : InputMethodService() {
    private val pages = linkedMapOf(
        "أرقام" to listOf("0","1","2","3","4","5","6","7","8","9","+","−","×","÷","=","⌫"),
        "رموز" to listOf("±","≠","≈","≤","≥","∞","π","θ","Δ","Σ","∈","∉","∩","∪","→","←"),
        "أسس" to listOf("x²","x³","xⁿ","x⁻¹","x⁻²","aᵇ","√","∛","ⁿ√","^"),
        "كسور" to listOf("½","⅓","¼","⅔","¾","كسر"),
        "هندسة" to listOf("∠","°","△","⊥","∥","sin","cos","tan","α","β","γ")
    )
    private var current = "أرقام"
    private lateinit var keys: LinearLayout

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(5,5,5,5)
            setBackgroundColor(Color.rgb(231,238,247))
        }
        root.addView(TextView(this).apply {
            text = "مستر محمد ربيع • رياضيات"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(23,54,93))
            setPadding(8,8,8,8)
        })
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        pages.keys.forEach { tab ->
            tabs.addView(Button(this).apply {
                text = tab
                textSize = 11f
                setOnClickListener { current = tab; showKeys() }
            }, LinearLayout.LayoutParams(0,48,1f))
        }
        root.addView(tabs)
        keys = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keys)
        showKeys()
        return root
    }

    private fun showKeys() {
        if (!::keys.isInitialized) return
        keys.removeAllViews()
        pages[current].orEmpty().chunked(4).forEach { row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { symbol ->
                line.addView(Button(this).apply {
                    text = symbol
                    textSize = 18f
                    setOnClickListener { insert(symbol) }
                }, LinearLayout.LayoutParams(0,52,1f))
            }
            keys.addView(line)
        }
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(Button(this).apply {
            text = "مسافة"
            setOnClickListener { currentInputConnection?.commitText(" ",1) }
        }, LinearLayout.LayoutParams(0,48,1f))
        bottom.addView(Button(this).apply {
            text = "محرر المعادلات"
            setOnClickListener {
                val intent = packageManager.getLaunchIntentForPackage(packageName)
                intent?.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                if (intent != null) startActivity(intent)
            }
        }, LinearLayout.LayoutParams(0,48,1f))
        bottom.addView(Button(this).apply {
            text = "↵"
            setOnClickListener { currentInputConnection?.commitText("\n",1) }
        }, LinearLayout.LayoutParams(0,48,1f))
        keys.addView(bottom)
    }

    private fun insert(value: String) {
        val ic: InputConnection = currentInputConnection ?: return
        when (value) {
            "⌫" -> ic.deleteSurroundingText(1,0)
            "كسر" -> ic.commitText("(   )/(   )",1)
            "x²" -> ic.commitText("²",1)
            "x³" -> ic.commitText("³",1)
            "xⁿ" -> ic.commitText("ⁿ",1)
            "x⁻¹" -> ic.commitText("⁻¹",1)
            "x⁻²" -> ic.commitText("⁻²",1)
            "aᵇ" -> ic.commitText("ᵇ",1)
            else -> ic.commitText(value,1)
        }
    }
}
